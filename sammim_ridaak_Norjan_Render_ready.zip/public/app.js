const categories = [
  {id:"tops",name:"الملابس العلوية والسفلية",items:["بلوزة","قميص","توب","كورسيه","بلوفر","هودي","بنطلون الجينز","سويت شيرت","بودي سوت","تونيك","كاميسول","التوب القصير","بنطلون قماش","بنطلون واسع","ليجنز","برمودا","شورت","تنورة","جيب شورت"]},
  {id:"dresses",name:"الفساتين والقطع المتصلة",items:["فستان كاجوال","فستان سهرة","فستان الزفاف","فستان كوكتيل","فستان ماكسي","جمبسوت","رومبر","سالوبيت"]},
  {id:"outer",name:"الملابس الخارجية",items:["جاكيت","بليزر","كارديجان","روب","معطف طويل","جاكيت منفوخ","باركا","شال","بونشو"]},
  {id:"sleep",name:"ملابس النوم والداخلية",items:["بجامة وقميص نوم","بيبي دول","طقم استرخاء","حمالة صدر","سراويل داخلية","لانجيري","كولون","مشد للجسم"]},
  {id:"sport",name:"الملابس الرياضية والسباحة",items:["طقم رياضي","مايوه","بكيني","كاش مايوه","بوركيني","بنطلون رياضة"]},
  {id:"traditional",name:"الملابس التقليدية والمحافظة",items:["عباءة","جلابية","اسدال صلاة","الحجاب","تونيك"]}
];

const common = {
  style:["أنيقة","كلاسيكية","راقية","سمارت كاجوال","شبه رسمي","لطيفة","كاجوال","بوهو","فينتج","مونوكروم","مينيمال","رومانسي","درامي"],
  pattern:["سادة","مخطط","زهور","هندسي","تجريدي","كاروهات","تارتان","باروكي","بيزلي","استوائية","زيجزاج","نقاط","قلوب","نجوم","فراشات","هندسة لونية","حيوانات","رخامي","تاي داي","تمويه","كرتوني","غوثيك","شعار","رخام فاخر"],
  fit:["منتظم","واسع","أوفر سايز","ضيق ومحدد للجسم","مفصل على الجسم","فضفاض"],
  neck:["بيتر بان","كشكشة","ربطة","دائرية","كول درابيه","قطرة","ماندرين","V","قارب/صابرينا","جوهرة","غربي","بحري","مربعة","أوف شولدر","قلب","كوين آن","V عميق","هالتر","أحزمة رفيعة","بدون حمالات","كتف واحد","غير متماثلة","تشوكر","عالية","موك نك","U","ياقة قميص","بولو"],
  sleeve:["عادي","بات وينغ","كتف بارد","بيشوب","واسع","عباءة","كيمونو","طبقات","ضيق عند المعصم","جرس","بالون/منفوخ","كاب","ملاك","بتلة/توليب","فراشة","فتحة جانبية","مشقوق","ملفوف"],
  sleeveLen:["طويل","عند المعصم","ثلاثة أرباع","قصير","نصف كم","بدون أكمام","عند الكتف","فوق الكوع","تحت الكوع"],
  length:["قصير","منتظم","متوسط","ميدي","ماكسي","فوق الركبة","عند الركبة","تحت الركبة","منتصف الساق","عند الكاحل","مقصر"],
  waist:["خصر مرتفع","خصر منخفض","خصر متوسط","خصر غير متماثل","خصر مطاطي","رباط","بابرباغ","مطاط عريض","كورسيه","بدون خصر"],
  leg:["مستقيم","سكيني","واسع","بوت كت","مفصل/تيبر","كارغو","فضفاض","مستقيم واسع","A-line","قلم رصاص","حورية البحر"],
  fabric:["قطن","بوليستر","كتان","حرير","فيسكوز/رايون","ليوسيل","أسيتات","شيفون","ساتان","دانتيل","تفتا","أورغانزا","كريب","تول","صوف","كشمير","ألباكا","موهير","أكريليك","دنيم","فلانيل","بوبلين","نيوبرين","بروكار","جاكار","مخمل","جلد","جلد صناعي","سويد","تويد","جاباردين","كوردروي","جيرسي","ريب نِت","مودال","إيلاستان","نايلون"],
  stretch:["غير مرن","مرونة خفيفة","مرونة متوسطة","مرونة عالية"],
  color:["أسود","أبيض","عاجي/كريمي","رمادي فاتح","رمادي فحمي","بيج","نيود","كاميل","بني شوكولاتة","بني كستنائي","أحمر","مرجاني","قرمزي","عنابي/نبيذي","فوشيا","وردي فاتح","وردي غباري","سلمون","أزرق كحلي","نيلي","أزرق ملكي","أزرق كهربائي","سماوي","أزرق بيبي","تركوازي","تيال","بنفسجي","لافندر","ليلكي","باذنجاني","أخضر زيتوني","زمردي","نعناعي","فستقي","مريمي","كاكي","أصفر ليموني","خردلي","برتقالي","مشمشي","نحاسي","باستيل","نيون","ذهبي معدني","فضي معدني","برونزي"],
  details:["جيوب","جيوب وهمية","كارغو","أزرار","أزرار مخفية","أزرار ذهبية","سحاب","سحاب مزدوج","أحزمة","فيونكات","مطاط مجمع","خصر مرتفع","خصر كورسيه","كشكش","دانتيل","شفاف","حواف خام","لفّ","طبقات","ثقوب زخرفية","تطريز","شرائط متباينة","خطوط جانبية","كسرات","شقوق","رقع","زهور ثلاثية الأبعاد","جاكار","حلقات وسلاسل","أبازيم","مسامير معدنية","خياطة ظاهرة","خرز","لؤلؤ","أحجار لامعة","ترتر","شراريب","أكتاف مبطنة","ياقة قابلة للإزالة","بطانة","تفاصيل كوب","تفصيل دعم V","فرو متباين","قطعة 2 في 1"]
};

const base = {
  top:["style","pattern","fit","neck","sleeve","sleeveLen","fabric","stretch","color","details"],
  bottom:["style","pattern","fit","waist","length","leg","fabric","stretch","color","details"],
  dress:["style","pattern","fit","neck","sleeve","sleeveLen","length","waist","fabric","stretch","color","details"],
  outer:["style","pattern","fit","neck","sleeve","sleeveLen","length","fabric","stretch","color","details"],
  sleep:["style","pattern","fit","neck","sleeve","sleeveLen","length","fabric","stretch","color","details"],
  inner:["style","pattern","fit","neck","length","fabric","stretch","color","details"],
  sport:["style","pattern","fit","neck","sleeve","sleeveLen","length","fabric","stretch","color","details"],
  traditional:["style","pattern","fit","neck","sleeve","sleeveLen","length","fabric","color","details"]
};

const kind = {};
["بلوزة","قميص","توب","كورسيه","بلوفر","هودي","سويت شيرت","بودي سوت","تونيك","كاميسول","التوب القصير"].forEach(x=>kind[x]="top");
["بنطلون الجينز","بنطلون قماش","بنطلون واسع","ليجنز","برمودا","شورت","تنورة","جيب شورت","بنطلون رياضة"].forEach(x=>kind[x]="bottom");
["فستان كاجوال","فستان سهرة","فستان الزفاف","فستان كوكتيل","فستان ماكسي","جمبسوت","رومبر","سالوبيت"].forEach(x=>kind[x]="dress");
["جاكيت","بليزر","كارديجان","روب","معطف طويل","جاكيت منفوخ","باركا","شال","بونشو"].forEach(x=>kind[x]="outer");
["بجامة وقميص نوم","بيبي دول","طقم استرخاء"].forEach(x=>kind[x]="sleep");
["حمالة صدر","سراويل داخلية","لانجيري","كولون","مشد للجسم"].forEach(x=>kind[x]="inner");
["طقم رياضي","مايوه","بكيني","كاش مايوه","بوركيني","بنطلون رياضة"].forEach(x=>kind[x]="sport");
["عباءة","جلابية","اسدال صلاة","الحجاب"].forEach(x=>kind[x]="traditional");

const labels = {
  style:"أسلوب التصميم",pattern:"النقشة",fit:"نوع الشكل والقصة",neck:"خط العنق والياقة",
  sleeve:"نوع الأكمام",sleeveLen:"طول الأكمام",length:"الطول",waist:"نوع الخصر",
  leg:"نوع القصّة/الساق",fabric:"نوع القماش والتكوين",stretch:"درجة مرونة القماش",
  color:"اللون ودرجته",details:"التفاصيل والإضافات"
};

let state={screen:"categories",category:null,garment:null,questions:[],index:0,answers:{}};
const content=document.getElementById("content");
const backBtn=document.getElementById("backBtn");
const esc=s=>String(s).replace(/[&<>'"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;","\"":"&quot;"}[c]));

function garmentIcon(name){
  const type=kind[name]||"top";
  const hue=Math.abs([...name].reduce((a,c)=>a*31+c.charCodeAt(0),7))%360;
  const shape=type==="dress"
    ? `<path d="M120 40Q100 80 105 135L55 260Q120 285 185 260L135 135Q140 80 120 40Z"/>`
    : type==="bottom"
    ? `<path d="M78 55L112 55L118 165L92 265L60 265L78 165Z"/><path d="M128 55L162 55L180 165L180 265L148 265L118 165Z"/>`
    : `<path d="M75 55Q120 35 165 55L205 130L165 150L150 100L150 260L90 260L90 100L75 150L35 130Z"/>`;
  return "data:image/svg+xml;charset=UTF-8,"+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 300"><defs><linearGradient id="g"><stop stop-color="hsl(${hue} 25% 24%)"/><stop offset="1" stop-color="hsl(${(hue+35)%360} 45% 65%)"/></linearGradient></defs><rect width="240" height="300" fill="#f4eee3"/><circle cx="190" cy="45" r="90" fill="hsl(${hue} 35% 85%)" opacity=".55"/><g fill="url(#g)" stroke="#8b6d39" stroke-width="4">${shape}</g><path d="M55 135Q120 170 185 135" fill="none" stroke="#e9d49b" stroke-width="5"/><text x="120" y="286" text-anchor="middle" font-family="Arial" font-size="14" fill="#5d4b31">${name}</text></svg>`);
}

function render(){
  backBtn.style.visibility=state.screen==="categories"?"hidden":"visible";
  if(state.screen==="categories") renderCategories();
  else if(state.screen==="garments") renderGarments();
  else if(state.screen==="questions") renderQuestion();
  else renderSummary();
}

function renderCategories(){
  content.innerHTML=`<section class="hero"><div class="eyebrow">مرحبًا بك في مساحة التصميم</div><h1>صمم رداءك</h1><p>اختاري قطعتك ثم خصصي القصة والياقة والقماش واللون والتفاصيل، وبعدها أنشئي الصورة بالذكاء الاصطناعي.</p></section><h2 class="section-title">اختاري الفئة</h2><div class="grid">${categories.map(c=>`<button class="category-card" onclick="selectCategory('${c.id}')"><strong>${c.name}</strong><small>${c.items.length} قطعة</small></button>`).join("")}</div>`;
}

function renderGarments(){
  content.innerHTML=`<div class="page-heading"><div><div class="eyebrow">${state.category.name}</div><h2 class="section-title">اختاري القطعة</h2></div><span class="count">${state.category.items.length} قطعة</span></div><div class="grid garment-grid">${state.category.items.map(name=>`<button class="garment-card" onclick="selectGarment(${JSON.stringify(name)})"><div class="garment-img"><img src="${garmentIcon(name)}" alt="${esc(name)}"></div><div class="garment-name">${esc(name)}</div></button>`).join("")}</div>`;
}

function selectCategory(id){
  state.category=categories.find(c=>c.id===id);
  state.screen="garments";
  render();
}

function selectGarment(name){
  state.garment=name;
  const k=kind[name]||"top";
  state.questions=base[k].map(key=>({key,label:labels[key],options:common[key]}));
  state.index=0;
  state.answers={};
  state.screen="questions";
  render();
}

function renderQuestion(){
  const q=state.questions[state.index];
  const pct=Math.round((state.index/state.questions.length)*100);
  content.innerHTML=`<div class="question-wrap"><div class="question-head"><span>تصميم ${esc(state.garment)}</span><b>${state.index+1}/${state.questions.length}</b></div><div class="progress"><span style="width:${pct}%"></span></div><div class="q-number">اختاري إجابة واحدة للمتابعة</div><h1 class="question">${q.label}</h1><div class="options">${q.options.map(o=>`<button class="option" onclick="answer(${JSON.stringify(q.key)},${JSON.stringify(o)})">${esc(o)}</button>`).join("")}</div></div>`;
}

function answer(key,value){
  state.answers[key]=value;
  if(state.index<state.questions.length-1) state.index++;
  else state.screen="summary";
  render();
}

function renderSummary(){
  const rows=Object.entries(state.answers).map(([k,v])=>`<div class="spec"><b>${labels[k]}</b><span>${esc(v)}</span></div>`).join("");
  content.innerHTML=`<div class="summary"><div class="eyebrow">المعاينة النهائية</div><h2>${esc(state.garment)}</h2><p class="summary-sub">هذه هي مواصفات التصميم التي اخترتها.</p><div class="preview-card"><img src="${garmentIcon(state.garment)}" alt="${esc(state.garment)}"><div><strong>${esc(state.garment)}</strong><span>جاهز للإنشاء بالذكاء الاصطناعي</span></div></div><div class="spec-list">${rows}</div><button class="create-btn" onclick="createDesign()">✨ إنشاء التصميم</button><div id="result"></div></div>`;
}

async function createDesign(){
  const result=document.getElementById("result");
  const button=document.querySelector(".create-btn");
  const specs=Object.entries(state.answers).map(([k,v])=>`${labels[k]}: ${v}`).join("، ");
  const prompt=`أنشئ صورة أزياء واقعية واحترافية لقطعة ${state.garment}. التزم بدقة بالمواصفات التالية: ${specs}. أظهر القطعة كاملة وواضحة، بتفاصيل دقيقة للقصة والخياطة والخامة والنقشة واللون والإضافات. اجعل التصميم يبدو كقطعة أزياء حقيقية قابلة للتنفيذ، بتنسيق تصوير أزياء احترافي وإضاءة استوديو ناعمة وخلفية بسيطة وأنيقة. لا تضف أي كتابة أو شعارات أو علامات مائية إلى الصورة.`;
  button.disabled=true;
  button.textContent="⏳ جاري إنشاء التصميم...";
  result.innerHTML=`<div class="result loading"><div class="spinner"></div><h3>جاري إنشاء تصميمك...</h3><p>الذكاء الاصطناعي يحوّل مواصفاتك إلى صورة.</p></div>`;
  try{
    const response=await fetch("/api/generate-image",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});
    const data=await response.json().catch(()=>({}));
    if(!response.ok) throw new Error(data.error||"تعذر إنشاء الصورة.");
    if(!data.image) throw new Error("لم تصل الصورة.");
    window.generatedDesign=data.image;
    result.innerHTML=`<div class="result result-image"><h3>✨ تم إنشاء تصميمك</h3><img class="generated-image" src="${data.image}" alt="التصميم الذي تم إنشاؤه"><div class="result-actions"><button class="secondary-btn" onclick="downloadDesign()">حفظ الصورة</button><button class="secondary-btn" onclick="createDesign()">إعادة الإنشاء</button></div></div>`;
  }catch(error){
    result.innerHTML=`<div class="result error"><div class="result-icon">!</div><h3>تعذر إنشاء الصورة</h3><p>${esc(error.message||"حدث خطأ غير متوقع.")}</p><p class="hint">تأكدي من إضافة OPENAI_API_KEY في Render ثم إعادة النشر.</p><button class="secondary-btn" onclick="createDesign()">حاول مرة أخرى</button></div>`;
  }finally{
    button.disabled=false;
    button.textContent="✨ إنشاء التصميم";
  }
}

function downloadDesign(){
  if(!window.generatedDesign)return;
  const a=document.createElement("a");
  a.href=window.generatedDesign;
  a.download="tasmeem-ridaak.png";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

backBtn.onclick=()=>{
  if(state.screen==="garments")state.screen="categories";
  else if(state.screen==="questions")state.screen="garments";
  else if(state.screen==="summary")state.screen="questions";
  render();
};

window.selectCategory=selectCategory;
window.selectGarment=selectGarment;
window.answer=answer;
window.createDesign=createDesign;
window.downloadDesign=downloadDesign;

setTimeout(()=>{
  document.getElementById("splash").classList.add("hidden");
  document.getElementById("main").classList.remove("hidden");
  render();
},2200);
