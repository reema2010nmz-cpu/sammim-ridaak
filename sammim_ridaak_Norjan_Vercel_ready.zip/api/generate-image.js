export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey || !apiKey.trim()) {
    return res.status(500).json({
      error: 'OPENAI_API_KEY غير موجود في Vercel. أضفه من Project Settings → Environment Variables ثم أعد النشر.'
    });
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const prompt = String(body.prompt || '').trim();
    if (!prompt) return res.status(400).json({ error: 'لم تصل مواصفات التصميم.' });

    const response = await fetch('https://api.openai.com/v1/images/generations', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-image-2',
        prompt,
        size: '1024x1024',
        quality: 'medium'
      })
    });

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || 'رفضت خدمة توليد الصور الطلب.'
      });
    }

    const item = data?.data?.[0];
    const b64 = item?.b64_json;
    const url = item?.url;
    if (!b64 && !url) return res.status(502).json({ error: 'لم تصل الصورة من خدمة توليد الصور.' });

    return res.status(200).json({
      image: b64 ? `data:image/png;base64,${b64}` : url
    });
  } catch (error) {
    return res.status(500).json({
      error: error?.message || 'حدث خطأ أثناء الاتصال بخدمة توليد الصور.'
    });
  }
}
